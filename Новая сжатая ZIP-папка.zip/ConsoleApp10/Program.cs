﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class PlinqSequence
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        string fileContent = "1 2 8 -1 4 2 7 9 15 5";

        List<int> numbers = new List<int>();

        try
        {
           
            numbers = fileContent
                .Split(new char[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => int.Parse(s.Trim()))
                .ToList();

            if (numbers.Count == 0)
            {
                Console.WriteLine("Файл порожній або містить некоректні дані.");
                return;
            }

            Console.WriteLine($"Вхідні дані: {string.Join(" ", numbers)}");

            
            int maxLength = CalculateMaxIncreasingSubsegmentLength(numbers);

            Console.WriteLine($"\nДовжина найбільшої зростаючої послідовності (суцільної): {maxLength}");
            
        }
        catch (FormatException)
        {
            Console.WriteLine("Помилка: Файл містить некоректні цілі числа.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Виникла помилка: {ex.Message}");
        }
    }

   
    
    private static int CalculateMaxIncreasingSubsegmentLength(List<int> data)
    {
        if (data == null || data.Count == 0)
        {
            return 0;
        }
        if (data.Count == 1)
        {
            return 1;
        }

       

        int maxLength = data.Count > 0 ? 1 : 0; 

        maxLength = Enumerable.Range(0, data.Count)
            .AsParallel()                           
            .Select(startIndex =>
            {
                int currentLength = 1;
                
                for (int i = startIndex + 1; i < data.Count; i++)
                {
                    
                    if (data[i] > data[i - 1])
                    {
                        currentLength++;
                    }
                    else
                    {
                        
                        break;
                    }
                }
                return currentLength;
            })
            .Max(); 

        return maxLength;
    }
}